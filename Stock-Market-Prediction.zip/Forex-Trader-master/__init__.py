class userVals():
    SMAbig = 50
    SMAsmall = 25
    count = 55
    key ="..."
    risk=0.02
    accountID = "..."
    pair="EUR_USD"
    params = {
    	"count": count,
    	"granularity": "H4"
    }